import os
from supabase import create_client, Client
from core.config import settings

def get_supabase_client() -> Client | None:
    if settings.SUPABASE_URL and settings.SUPABASE_KEY:
        try:
            return create_client(settings.SUPABASE_URL, settings.SUPABASE_KEY)
        except Exception as e:
            print(f"Error initializing Supabase client: {e}")
            return None
    return None

supabase: Client | None = get_supabase_client()
